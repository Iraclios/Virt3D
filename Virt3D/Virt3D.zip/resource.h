﻿//{{NO_DEPENDENCIES}}
// Включаемый файл, созданный в Microsoft Visual C++.
// Используется Virt3D.rc
//
#define IDC_MYICON                      2
#define IDD_VIRT3D_DIALOG               102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_VIRT3D                      107
#define IDI_SMALL                       108
#define IDC_VIRT3D                      109
#define IDR_MAINFRAME                   128
#define IDM_ADD                         201
#define IDD_ADD                         202
#define IDM_REND                        203
#define IDD_REND                        204
#define IDM_REFLECT                     301
#define IDM_ROTATE                      302
#define IDM_SCALAR                      303
#define IDM_TRANSLATE                   304
#define IDD_REFLECT                     305
#define IDD_TRANSLATE                   306
#define IDD_ROTATE                      307
#define IDD_SCALAR                      308
#define IDD_EVERY                       309
#define IDD_DIST                        310
#define IDC_MFCEDITBROWSE1              1000
#define IDC_TREE1                       1006
#define IDC_COMBO1                      1007
#define IDC_CHECK4                      1013
#define IDC_CHECK5                      1014
#define IDC_CHECK6                      1015
#define IDC_EDIT1                       1016
#define IDC_EDIT2                       1017
#define IDC_EDIT3                       1018
#define IDC_EDIT4                       1019
#define IDC_EDIT5                       1020
#define IDC_EDIT6                       1021
#define IDC_EDIT7                       1022
#define IDC_EDIT8                       1024
#define IDC_CHECK2                      1025
#define IDC_EDIT9                       1026
#define IDC_EDIT10                      1027
#define IDC_EDIT11                      1028
#define IDC_EDIT12                      1029
#define IDC_COMBO2                      1030
#define IDC_CHECK1                      1031
#define IDC_COMBO3                      1032
#define IDC_SCROLLBAR1                  1033
#define ID_32773                        32773
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define IDD                             32780
#define IDM_TRANS                       32781
#define ID_32786                        32786
#define IDM_ORIG                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define IDM_ORTH                        32790
#define ID_32791                        32791
#define IDM_DIST                        32792
#define IDM_CAMERA                      32793
#define IDM_EVERY                       32794
#define ID                              32795
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
